import logging
import requests
from bs4 import BeautifulSoup

from dead_links_manager import DeadLinksManager
dead_links_manager = DeadLinksManager()

# change for other models, OpenAi, Google Ai, etc
from keybert_keyword_extractor import KeyBERTKeywordExtractor

def fetch_page_text(url, timeout=15, max_words=1500):
    try:
        response = requests.get(url, timeout=timeout)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, "html.parser")
        text = soup.get_text(separator=" ", strip=True)
        # words = text.split()
        return text
        # return " ".join(words[:max_words])
    except Exception as e:
        logging.error(f"Failed to fetch or parse {url}: {e}")
        return ""

def batch_extract_keywords(bookmarks, storage, max_words=1500, top_n=5):
    extractor = KeyBERTKeywordExtractor(top_n=top_n)
    for bookmark in bookmarks:
        if not bookmark.keywords and bookmark.is_valid and not dead_links_manager.is_dead(bookmark.url):
            page_text = fetch_page_text(bookmark.url, max_words=max_words)
            if not page_text:
                logging.warning(f"No text fetched for {bookmark.url}, skipping KeyBERT extraction.")
                bookmark.keywords = []
                continue
            try:
                keywords = extractor.extract_keywords(page_text)
                bookmark.keywords = keywords
                storage.save()
                logging.info(f"Keywords for {bookmark.url}: {keywords}")
            except Exception as e:
                logging.error(f"Failed to extract keywords for {bookmark.url}: {e}")
                bookmark.keywords = []