import logging
from typing import List, Dict, Any, Optional

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation


class LDABatchExtractor:
    """
    Classical LDA topic modeling for comparison with BERTopic.
    Produces global topic keyword lists and per-document topic distributions.
    """
    def __init__(
        self,
        n_topics: int = 20,
        max_features: int = 20000,
        top_n_per_doc: int = 3,
        min_topic_probability: float = 0.02,
        random_state: int = 42,
    ):
        self.n_topics = n_topics
        self.max_features = max_features
        self.top_n_per_doc = top_n_per_doc
        self.min_topic_probability = min_topic_probability
        self.random_state = random_state
        self.vectorizer: Optional[CountVectorizer] = None
        self.lda_model: Optional[LatentDirichletAllocation] = None
        self.feature_names: Optional[List[str]] = None
        self._fitted = False
        self.logger = logging.getLogger(__name__)

    def fit(self, docs: List[str]) -> Dict[str, Any]:
        self.logger.info("Fitting LDA on %d documents (topics=%d)...", len(docs), self.n_topics)
        self.vectorizer = CountVectorizer(
            stop_words="english",
            max_features=self.max_features
        )
        X = self.vectorizer.fit_transform(docs)
        self.feature_names = list(self.vectorizer.get_feature_names_out())

        self.lda_model = LatentDirichletAllocation(
            n_components=self.n_topics,
            max_iter=20,
            learning_method="batch",
            random_state=self.random_state
        )
        self.lda_model.fit(X)
        doc_topic = self.lda_model.transform(X)
        self._fitted = True
        self.logger.info("LDA fit complete.")
        return {
            "doc_topic_matrix": doc_topic
        }

    def get_global_topics(self, top_k: int = 30) -> List[Dict[str, Any]]:
        if not self._fitted or self.lda_model is None or self.feature_names is None:
            raise RuntimeError("LDA model not fitted.")
        topics_out = []
        for tid, comp in enumerate(self.lda_model.components_):
            # Higher weight words
            top_indices = comp.argsort()[::-1][:top_k]
            keywords = [
                {
                    "word": self.feature_names[i],
                    "score": float(comp[i])
                }
                for i in top_indices
            ]
            topics_out.append({
                "topic_id": tid,
                "keywords": keywords,
                "representation": [kw["word"] for kw in keywords]
            })
        return topics_out

    def get_top_topics_per_document(
        self,
        doc_topic_matrix,
        top_n: Optional[int] = None
    ) -> List[List[Dict[str, Any]]]:
        """
        Returns per-document list of top topics filtered by min_topic_probability.
        Each entry: {topic_id, probability, keywords:[{word,score}...]}.
        """
        if not self._fitted or self.lda_model is None:
            raise RuntimeError("LDA model not fitted.")
        if top_n is None:
            top_n = self.top_n_per_doc

        # Precompute topic keywords (once)
        topic_keyword_cache = {}
        for tid in range(self.n_topics):
            comp = self.lda_model.components_[tid]
            # reuse smaller top list for per-doc context
            top_indices = comp.argsort()[::-1][:25]
            topic_keyword_cache[tid] = [
                {"word": self.feature_names[i], "score": float(comp[i])}
                for i in top_indices
            ]

        results = []
        for row in doc_topic_matrix:
            topic_prob_pairs = [
                (tid, float(prob))
                for tid, prob in enumerate(row)
                if prob >= self.min_topic_probability
            ]
            topic_prob_pairs.sort(key=lambda x: x[1], reverse=True)
            selected = topic_prob_pairs[:top_n]
            doc_topics = []
            for tid, p in selected:
                doc_topics.append({
                    "topic_id": tid,
                    "probability": p,
                    "keywords": topic_keyword_cache[tid]
                })
            results.append(doc_topics)
        return results