"""
Placeholder for future LDA integration.

You can later implement classical LDA to compare with BERTopic.
Typical steps:

1. Vectorize documents:
   from sklearn.feature_extraction.text import CountVectorizer
   vectorizer = CountVectorizer(stop_words='english', max_features=20000)
   X = vectorizer.fit_transform(docs)

2. Fit LDA:
   from sklearn.decomposition import LatentDirichletAllocation
   lda = LatentDirichletAllocation(
       n_components=NUM_TOPICS,
       learning_method='batch',
       max_iter=20,
       random_state=42
   )
   lda.fit(X)

3. Get topic-word distributions:
   vocab = vectorizer.get_feature_names_out()
   for topic_idx, topic_dist in enumerate(lda.components_):
       top_indices = topic_dist.argsort()[::-1][:TOP_N]
       keywords = [vocab[i] for i in top_indices]

4. Per-document topic distribution:
   doc_topic = lda.transform(X)[doc_index]

5. Store in bookmark.topics similar to BERTopic output:
   bookmark.topics = [
       {"topic_id": tid, "probability": prob, "keywords": [...]} ...
   ]
"""