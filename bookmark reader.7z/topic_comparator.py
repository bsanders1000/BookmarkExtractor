import json
import logging
from typing import List, Dict, Any, Optional
from itertools import product

logger = logging.getLogger(__name__)


def _topic_keyword_set(topic: Dict[str, Any], top_k: int) -> set:
    return set([kw["word"] for kw in topic.get("keywords", [])[:top_k]])


def jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def compare_topic_models(
    bertopic_topics: List[Dict[str, Any]],
    lda_topics: List[Dict[str, Any]],
    top_k: int = 15,
    min_similarity: float = 0.05
) -> Dict[str, Any]:
    """
    Produce a (greedy) similarity matching between BERTopic and LDA topics based on
    Jaccard overlap of top_k keywords.
    """
    logger.info("Comparing %d BERTopic topics with %d LDA topics...", len(bertopic_topics), len(lda_topics))

    # Build similarity matrix
    sims = []
    for bt, lt in product(bertopic_topics, lda_topics):
        b_set = _topic_keyword_set(bt, top_k)
        l_set = _topic_keyword_set(lt, top_k)
        sim = jaccard(b_set, l_set)
        if sim >= min_similarity:
            sims.append((sim, bt["topic_id"], lt["topic_id"]))
    # Sort descending by similarity
    sims.sort(reverse=True, key=lambda x: x[0])

    matched_bert = set()
    matched_lda = set()
    matches = []

    for sim, btid, ltid in sims:
        if btid in matched_bert or ltid in matched_lda:
            continue
        matches.append({
            "bertopic_id": btid,
            "lda_id": ltid,
            "similarity": sim
        })
        matched_bert.add(btid)
        matched_lda.add(ltid)

    unmatched_bertopic = [t["topic_id"] for t in bertopic_topics if t["topic_id"] not in matched_bert]
    unmatched_lda = [t["topic_id"] for t in lda_topics if t["topic_id"] not in matched_lda]

    return {
        "matches": matches,
        "unmatched_bertopic": unmatched_bertopic,
        "unmatched_lda": unmatched_lda,
        "params": {
            "top_k": top_k,
            "min_similarity": min_similarity
        }
    }


def save_comparison(
    comparison: Dict[str, Any],
    path: str
):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(comparison, f, indent=2)
        logger.info("Saved topic model comparison to %s", path)
    except Exception as e:
        logger.error("Failed to save comparison: %s", e)