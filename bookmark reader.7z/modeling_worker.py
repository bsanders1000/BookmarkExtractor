import traceback
from PyQt5.QtCore import QThread, pyqtSignal

# We import the updated run function with LDA + callbacks
from topic_batch_processor import run_batch_topic_modeling


class ModelingWorker(QThread):
    progress = pyqtSignal(int, str)   # percent, stage label
    finished_success = pyqtSignal(dict)  # results dict
    failed = pyqtSignal(str)

    def __init__(
        self,
        bookmarks,
        storage_path: str,
        cache_path: str,
        run_lda: bool = False,
        lda_num_topics: int = 20,
        compute_comparison: bool = False,
        comparison_top_k: int = 15,
        comparison_min_similarity: float = 0.05,
        parent=None
    ):
        super().__init__(parent)
        self.bookmarks = bookmarks
        self.storage_path = storage_path
        self.cache_path = cache_path
        self.run_lda = run_lda
        self.lda_num_topics = lda_num_topics
        self.compute_comparison = compute_comparison
        self.comparison_top_k = comparison_top_k
        self.comparison_min_similarity = comparison_min_similarity

    def _progress_callback(self, current: int, total: int, stage: str, weight: float, absolute_progress: float):
        # absolute_progress provided by orchestrator (0-100 already)
        self.progress.emit(int(absolute_progress), f"{stage} ({current}/{total})" if total else stage)

    def run(self):
        try:
            results = run_batch_topic_modeling(
                self.bookmarks,
                save_path=self.storage_path,
                content_cache_path=self.cache_path,
                force_refetch=False,
                fetch_limit=None,
                max_words=3000,
                polite_delay=0.25,
                user_agent="BookmarkTopicBot/1.0",
                top_n_per_doc=3,
                min_topic_probability=0.02,
                embedding_model="all-MiniLM-L6-v2",
                nr_topics=None,
                verbose=False,
                run_lda=self.run_lda,
                lda_num_topics=self.lda_num_topics,
                lda_max_features=20000,
                lda_min_topic_probability=0.02,
                lda_top_n_per_doc=3,
                compute_comparison=self.compute_comparison,
                comparison_top_k=self.comparison_top_k,
                comparison_min_similarity=self.comparison_min_similarity,
                progress_callback=self._progress_callback
            )
            self.finished_success.emit(results)
        except Exception as e:
            tb = traceback.format_exc()
            self.failed.emit(f"{e}\n{tb}")