import time
import logging
from gemini_keyword_extractor import GeminiKeywordExtractor

logger = logging.getLogger(__name__)

def process_bookmarks_with_gemini(bookmarks, api_key):
    extractor = GeminiKeywordExtractor(api_key)
    for bookmark in bookmarks:
        page_text = bookmark['content']  # Adjust per your data structure
        url = bookmark['url']
        try_count = 0
        while True:
            try:
                keywords = extractor.extract_keywords(page_text)
                logger.info(f"Keywords for {url}: {keywords}")
                bookmark['keywords'] = keywords
                break
            except Exception as e:
                err = str(e)
                # Handle Gemini 429 with retry_delay
                if "429" in err and "retry_delay" in err:
                    import re
                    match = re.search(r'retry_delay\s*{\s*seconds:\s*(\d+)', err)
                    if match:
                        delay = int(match.group(1))
                        logger.warning(
                            f"Gemini API rate limit hit for {url}. Sleeping for {delay} seconds..."
                        )
                        print(f"Rate limit hit. Sleeping for {delay} seconds...")
                        time.sleep(delay)
                        try_count += 1
                        continue
                # Handle daily limit
                if "Daily Gemini API quota exceeded" in err:
                    logger.error(
                        "Daily Gemini API quota reached. Pausing batch job until tomorrow."
                    )
                    print("Daily quota reached. Processing will resume tomorrow.")
                    return  # Stop the job for today
                # Handle minute limit
                if "Per-minute Gemini API quota exceeded" in err:
                    logger.warning(
                        "Per-minute Gemini API quota reached. Sleeping for 65 seconds."
                    )
                    print("Per-minute quota reached. Sleeping for 65 seconds...")
                    time.sleep(65)
                    try_count += 1
                    continue
                # Other errors
                logger.error(f"Gemini API failed for {url}: {err}")
                bookmark['keywords'] = []
                break

# Example usage:
# bookmarks = [{'url': ..., 'content': ...}, ...]
# process_bookmarks_with_gemini(bookmarks, "YOUR_GEMINI_API_KEY")