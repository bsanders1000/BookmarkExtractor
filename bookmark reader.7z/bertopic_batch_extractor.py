# (Unchanged from prior version you adopted; included here only if you need a reminder)
# If you already have this file with the same class, you can keep your existing copy.
from bertopic import BERTopic
import logging
from typing import List, Dict, Any, Optional


class BERTopicBatchExtractor:
    def __init__(
        self,
        top_n_per_doc: int = 3,
        min_topic_probability: float = 0.01,
        embedding_model: Optional[str] = "all-MiniLM-L6-v2",
        nr_topics: Optional[int] = None,
        verbose: bool = False,
    ):
        self.top_n_per_doc = top_n_per_doc
        self.min_topic_probability = min_topic_probability
        self.model = BERTopic(
            embedding_model=embedding_model,
            calculate_probabilities=True,
            nr_topics=nr_topics,
            verbose=verbose,
        )
        self._fitted = False
        self.logger = logging.getLogger(__name__)

    def fit(self, docs: List[str]):
        topics, probs = self.model.fit_transform(docs)
        self._fitted = True
        return {"topics": topics, "probabilities": probs}

    def get_global_topics(self) -> List[Dict[str, Any]]:
        if not self._fitted:
            raise RuntimeError("Model not fitted.")
        topic_info = self.model.get_topics()
        results = []
        for topic_id, word_scores in topic_info.items():
            if topic_id == -1:
                continue
            results.append({
                "topic_id": topic_id,
                "keywords": [{"word": w, "score": float(s)} for w, s in word_scores],
                "representation": [w for w, _ in word_scores],
            })
        return results

    def get_top_topics_per_document(self, probs, topics: List[int]):
        if probs is None:
            # fallback: only primary
            out = []
            for t in topics:
                if t == -1:
                    out.append([])
                else:
                    kw = self.model.get_topic(t) or []
                    out.append([{
                        "topic_id": t,
                        "probability": 1.0,
                        "keywords": [{"word": w, "score": float(s)} for w, s in kw]
                    }])
            return out

        # Build mapping from model freq order to topic ids
        topic_freq_df = self.model.get_topic_freq()
        valid_topic_ids = [tid for tid in topic_freq_df.Topic if tid != -1]

        results = []
        for doc_probs in probs:
            topic_prob_pairs = []
            for pos, tid in enumerate(valid_topic_ids):
                if pos >= len(doc_probs):
                    break
                p = doc_probs[pos]
                if p is None:
                    continue
                if p >= self.min_topic_probability:
                    topic_prob_pairs.append((tid, float(p)))
            topic_prob_pairs.sort(key=lambda x: x[1], reverse=True)
            selected = topic_prob_pairs[: self.top_n_per_doc]
            doc_topic_entries = []
            for tid, p in selected:
                kw = self.model.get_topic(tid) or []
                doc_topic_entries.append({
                    "topic_id": tid,
                    "probability": p,
                    "keywords": [{"word": w, "score": float(s)} for w, s in kw]
                })
            results.append(doc_topic_entries)
        return results