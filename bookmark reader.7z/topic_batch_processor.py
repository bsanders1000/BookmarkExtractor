import logging
from typing import List, Any, Callable, Optional, Dict
import json
from pathlib import Path

from bertopic_batch_extractor import BERTopicBatchExtractor
from fetcher import fetch_page_text
from storage_utils import save_bookmarks

# New imports for LDA + comparison
from lda_extractor import LDABatchExtractor
from topic_comparator import compare_topic_models, save_comparison

logger = logging.getLogger(__name__)


def collect_documents(
    bookmarks: List[Any],
    content_cache_path: Optional[str] = None,
    force_refetch: bool = False,
    fetch_limit: Optional[int] = None,
    max_words: int = 3000,
    polite_delay: float = 0.0,
    user_agent: Optional[str] = None,
    progress_callback: Optional[Callable[[int, int, str, float, float], None]] = None,
) -> Dict[int, str]:
    """
    Fetch (or load cached) page text for valid bookmarks.
    progress_callback(current, total, stage, weight, absolute_progress)
    weight & absolute_progress let orchestrator allocate global progress.
    """
    stage = "Fetching"
    cache = {}
    cache_path = Path(content_cache_path) if content_cache_path else None

    if cache_path and cache_path.exists() and not force_refetch:
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                cache = json.load(f)
            logger.info("Loaded %d cached pages from %s", len(cache), cache_path)
        except Exception as e:
            logger.warning("Failed to load cache (%s). Proceeding fresh.", e)

    doc_map = {}
    valid_bookmarks = [
        (idx, b) for idx, b in enumerate(bookmarks)
        if getattr(b, "is_valid", True) and getattr(b, "url", None)
    ]
    total = len(valid_bookmarks)
    fetched = 0

    for idx, bm in valid_bookmarks:
        url = getattr(bm, "url")
        if cache and url in cache:
            text = cache[url]
        else:
            text = fetch_page_text(
                url,
                max_words=max_words,
                sleep_between=polite_delay,
                user_agent=user_agent
            )
            if cache_path and text:
                cache[url] = text

        if text:
            doc_map[idx] = text
        fetched += 1

        if progress_callback:
            # weight allocated later by caller; here just pass dummy 0 for weight/abs, orchestrator will wrap
            progress_callback(fetched, total, stage, 0.0, 0.0)

        if fetch_limit and len(doc_map) >= fetch_limit:
            logger.info("Fetch limit %d reached; stopping collection.", fetch_limit)
            break

    if cache_path:
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump(cache, f)
            logger.info("Saved updated content cache with %d entries.", len(cache))
        except Exception as e:
            logger.warning("Failed to write cache: %s", e)

    logger.info("Collected %d documents for modeling.", len(doc_map))
    return doc_map


def assign_topics_to_bookmarks(
    bookmarks: List[Any],
    doc_index_map: Dict[int, str],
    extractor: BERTopicBatchExtractor,
    topics: List[int],
    probs,
    save_path: Optional[str] = None,
    save_every: int = 25,
    progress_callback: Optional[Callable[[int, int, str, float, float], None]] = None,
):
    stage = "Assigning BERTopic"
    ordered_indices = list(doc_index_map.keys())
    doc_topics_list = extractor.get_top_topics_per_document(probs, topics)

    for i, bm_index in enumerate(ordered_indices):
        bookmark = bookmarks[bm_index]
        per_doc_topics = doc_topics_list[i] if i < len(doc_topics_list) else []
        setattr(bookmark, "topics", per_doc_topics)
        if per_doc_topics:
            first_topic_keywords = per_doc_topics[0].get("keywords", [])
            setattr(bookmark, "keywords", [kw["word"] for kw in first_topic_keywords[:5]])
        else:
            setattr(bookmark, "keywords", [])

        if (i + 1) % save_every == 0 and save_path:
            save_bookmarks(bookmarks, save_path)

        if progress_callback:
            progress_callback(i + 1, len(ordered_indices), stage, 0.0, 0.0)

    if save_path:
        save_bookmarks(bookmarks, save_path)


def assign_lda_topics_to_bookmarks(
    bookmarks: List[Any],
    doc_index_map: Dict[int, str],
    lda_extractor: LDABatchExtractor,
    doc_topic_matrix,
    save_path: Optional[str] = None,
    save_every: int = 25,
    progress_callback: Optional[Callable[[int, int, str, float, float], None]] = None,
):
    stage = "Assigning LDA"
    ordered_indices = list(doc_index_map.keys())
    lda_doc_topics = lda_extractor.get_top_topics_per_document(doc_topic_matrix)

    for i, bm_index in enumerate(ordered_indices):
        b = bookmarks[bm_index]
        topics = lda_doc_topics[i]
        setattr(b, "lda_topics", topics)
        if not getattr(b, "lda_keywords", None) and topics:
            setattr(b, "lda_keywords", [kw["word"] for kw in topics[0]["keywords"][:5]])

        if (i + 1) % save_every == 0 and save_path:
            save_bookmarks(bookmarks, save_path)

        if progress_callback:
            progress_callback(i + 1, len(ordered_indices), stage, 0.0, 0.0)

    if save_path:
        save_bookmarks(bookmarks, save_path)


def run_batch_topic_modeling(
    bookmarks: List[Any],
    save_path: str,
    content_cache_path: Optional[str] = None,
    force_refetch: bool = False,
    fetch_limit: Optional[int] = None,
    max_words: int = 3000,
    polite_delay: float = 0.0,
    user_agent: Optional[str] = None,
    top_n_per_doc: int = 3,
    min_topic_probability: float = 0.01,
    embedding_model: str = "all-MiniLM-L6-v2",
    nr_topics: Optional[int] = None,
    verbose: bool = False,
    # LDA + comparison params
    run_lda: bool = False,
    lda_num_topics: int = 20,
    lda_max_features: int = 20000,
    lda_min_topic_probability: float = 0.02,
    lda_top_n_per_doc: int = 3,
    compute_comparison: bool = False,
    comparison_top_k: int = 15,
    comparison_min_similarity: float = 0.05,
    # Progress callback
    progress_callback: Optional[Callable[[int, int, str, float, float], None]] = None,
):
    """
    Orchestrates:
      1. Fetch documents
      2. Fit BERTopic
      3. (Optional) Fit LDA
      4. Assign topics
      5. (Optional) Assign LDA + comparison
      6. Save artifacts
    Global progress allocation (adjustable):
      Fetching: 0-55%
      BERTopic fit: 55-70%
      Assign BERTopic: 70-82%
      LDA fit (optional): 82-90%
      Assign LDA (optional): 90-96%
      Comparison (optional): 96-99%
      Final save: 99-100%
    """
    def wrap_progress(local_cb, start_pct, end_pct):
        """
        Takes a callback from a stage reporting (current, total, stage_name,...)
        and maps to global absolute progress.
        """
        def _inner(current, total, stage, weight_unused, abs_unused):
            if total:
                frac = min(1.0, max(0.0, current / total))
            else:
                frac = 1.0
            absolute = start_pct + (end_pct - start_pct) * frac
            if progress_callback:
                progress_callback(current, total, stage, 0.0, absolute)
        return _inner

    logger.info("Starting batch topic modeling (BERTopic%s) on %d bookmarks.",
                " + LDA" if run_lda else "", len(bookmarks))

    # Stage 1: Fetch
    fetch_cb = wrap_progress(progress_callback, 0, 55)
    doc_index_map = collect_documents(
        bookmarks,
        content_cache_path=content_cache_path,
        force_refetch=force_refetch,
        fetch_limit=fetch_limit,
        max_words=max_words,
        polite_delay=polite_delay,
        user_agent=user_agent,
        progress_callback=fetch_cb
    )
    if not doc_index_map:
        logger.warning("No documents collected. Aborting.")
        return {}

    ordered_doc_indices = list(doc_index_map.keys())
    docs_in_order = [doc_index_map[i] for i in ordered_doc_indices]

    # Stage 2: Fit BERTopic
    if progress_callback:
        progress_callback(0, 1, "Fitting BERTopic", 0.0, 55)
    extractor = BERTopicBatchExtractor(
        top_n_per_doc=top_n_per_doc,
        min_topic_probability=min_topic_probability,
        embedding_model=embedding_model,
        nr_topics=nr_topics,
        verbose=verbose,
    )
    fit_result = extractor.fit(docs_in_order)
    if progress_callback:
        progress_callback(1, 1, "Fitting BERTopic", 0.0, 70)
    topics = fit_result["topics"]
    probs = fit_result["probabilities"]

    # Stage 3: Assign BERTopic
    assign_cb = wrap_progress(progress_callback, 70, 82)
    assign_topics_to_bookmarks(
        bookmarks,
        doc_index_map,
        extractor,
        topics,
        probs,
        save_path=save_path,
        progress_callback=assign_cb
    )
    global_topics = extractor.get_global_topics()
    global_topics_path = save_path.rsplit(".", 1)[0] + "_global_topics.json"
    try:
        with open(global_topics_path, "w", encoding="utf-8") as f:
            json.dump(global_topics, f, indent=2)
        logger.info("Saved BERTopic global topics to %s", global_topics_path)
    except Exception as e:
        logger.error("Failed to save BERTopic global topics: %s", e)

    lda_global_topics = []
    comparison_result = {}

    if run_lda:
        # Stage 4: Fit LDA
        if progress_callback:
            progress_callback(0, 1, "Fitting LDA", 0.0, 82)
        lda_extractor = LDABatchExtractor(
            n_topics=lda_num_topics,
            max_features=lda_max_features,
            top_n_per_doc=lda_top_n_per_doc,
            min_topic_probability=lda_min_topic_probability
        )
        lda_fit = lda_extractor.fit(docs_in_order)
        if progress_callback:
            progress_callback(1, 1, "Fitting LDA", 0.0, 90)

        # Stage 5: Assign LDA
        lda_assign_cb = wrap_progress(progress_callback, 90, 96)
        assign_lda_topics_to_bookmarks(
            bookmarks,
            doc_index_map,
            lda_extractor,
            lda_fit["doc_topic_matrix"],
            save_path=save_path,
            progress_callback=lda_assign_cb
        )
        lda_global_topics = lda_extractor.get_global_topics()
        lda_global_path = save_path.rsplit(".", 1)[0] + "_lda_global_topics.json"
        try:
            with open(lda_global_path, "w", encoding="utf-8") as f:
                json.dump(lda_global_topics, f, indent=2)
            logger.info("Saved LDA global topics to %s", lda_global_path)
        except Exception as e:
            logger.error("Failed to save LDA global topics: %s", e)

        if compute_comparison:
            # Stage 6: Compare
            if progress_callback:
                progress_callback(0, 1, "Comparing Models", 0.0, 96)
            comparison_result = compare_topic_models(
                global_topics,
                lda_global_topics,
                top_k=comparison_top_k,
                min_similarity=comparison_min_similarity
            )
            comp_path = save_path.rsplit(".", 1)[0] + "_topic_comparison.json"
            save_comparison(comparison_result, comp_path)
            if progress_callback:
                progress_callback(1, 1, "Comparing Models", 0.0, 99)

    # Final save
    save_bookmarks(bookmarks, save_path)
    if progress_callback:
        progress_callback(1, 1, "Done", 0.0, 100)

    logger.info("Batch topic modeling complete.")
    return {
        "bertopic_global_topics": global_topics,
        "lda_global_topics": lda_global_topics,
        "comparison": comparison_result
    }